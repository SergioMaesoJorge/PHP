<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Fundamentos php</h2>
    <?php
    echo("<h3>Texto en PHP</h3>");
    //Comentario de línea
    /* comentario de bloque
    */
    $unidades=15;
    $precio=9.95;
    $descuento=TRUE;
    $mensaje="Gracias por su compra";
    if($descuento)
    $total=$unidades*$precio*0.9;
    else
    $total=$unidades*$precio;
    echo("<h4>El total es ".$total."</h4>");
    ?>
</body>
</html>