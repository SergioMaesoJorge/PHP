<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Acceso a archivos</h2>
    <ul>
        <li><a href="accesotxt.php">Gestionar archivos de texto</a></li>
        <li><a href="ejercicioaccesotxt.php">Práctica de archivos de texto</a></li>
        <li><a href="accesojson.php">Gestionar archivos JSON</a></li>
        <li><a href="ejercicioaccesojson.php">Práctica de archivos JSON</a></li>
        <li><a href="accesoxml.php">Gestionar archivos XML</a></li>
        <li><a href="ejercicioaccesoxml.php">Práctica archivos XML</a></li>
        <li><a href="practicatxt.php">Práctica txt</a></li>
    </ul>
</body>
</html>