<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Gestionar XML</h2>
    <a href="https://academy.leewayweb.com/como-recorrer-un-archivo-xml-usando-php/">Enlace de referencia</a>

    <?php
    
    $archivo_leer=fopen("archivos/customers.xml","r");
        $contenido="";
        //$lectura=fgets($archivo_leer); //sólo lees una línea
        while($lectura=fgets($archivo_leer)){
            $contenido.=$lectura;
        }
        fclose($archivo_leer);
        //echo($contenido);
        //echo("fin de lectura");

       
    $xml=new SimpleXMLElement($contenido);
    //var_dump($xml);
    foreach ( $xml->children() as $child ) {
        echo("<p>".$child["full-name"] ."</p>");
    }
   
    ?>

</body>
</html>