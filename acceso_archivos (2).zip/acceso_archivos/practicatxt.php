<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Leer - escribir ficheros</h2>
    <?php
    $practica=fopen("archivos/carta.txt","a");
    $texto="Un texto para añadir";
    fwrite($practica,$texto);
    $lectura=fopen("archivos/carta.txt","r");
    $leer=fgets($lectura);
    echo($leer);
    $contenido="";
    while($leer=fgets($lectura)){
        $contenido.="<p>".$leer."</p>";
    }
    ?>
</body>
</html>