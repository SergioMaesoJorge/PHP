<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h3>Petición get</h3>
    <form method="get" action="post.php">
        <p></p>
        <input type="submit" value="petición GET - ver todo">
    </form>
    <form method="get" action="post.php">
        <p></p>
        <input type="number" name="id">
        <p></p>
        <input type="submit" value="petición GET - by ID">
    </form>
    <h2>a</h2>
    <form method="post" action="post.php">
        <p></p>
        <input type="text" name="title">
        <p></p>
        <input type="radio" name="status" value="draft">
        <label for="draft">draft</label>
        <input type="radio" name="status" value="published">
        <label for="published">Published</label>
        <p></p>
        <input type="text" name="content">
        <p></p>
        <input type="number" name="user_id">
        <p></p>
        
        <input type="submit" value="petición GET - by ID">
    </form>
    <form method="get" action="post.php">
        <p></p>
        <input type="text" name="nombre">
        <p></p>
        <input type="datetime" name="fecha">
        <p></p>
        <input type="text" name="foto">
        <p></p>
        <input type="submit" value="petición GET - by ID">
    </form>
</body>
</html>