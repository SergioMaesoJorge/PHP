<?php
class Padre{

public function saludarPadre(){
    echo("<p>hola, desde la clase padre</p>");
}

}//cierra clase