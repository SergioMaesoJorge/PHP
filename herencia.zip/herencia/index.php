<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Herencia en PHP</h2>
    <?php
    require_once('cliente.php');
    require_once('hija.php');//instancias clase Hija
    $cliente1=new Cliente("repsol","málaga",123.95);//instanciar
    $cliente1->fichaCliente();//llamar al método
    //$cliente1->ciudad="sevilla"; //NO usas encapsulamiento
    $cliente1->setCiudad("zaragoza");
    $cliente1->fichaCliente();//llamar al método
    echo("<hr");
    $hija1=new Hija(); //instanciar la clase hija
    $hija1->saludarHija();
    $hija1->saludarPadre();//usando un método de su clase Padre : herencia funciona
    $padre1=new Padre();//instancia ok aunque la clase Padre no require porque Padre require en Hija
    $padre1->saludarPadre();
    $hija1->saludarHija("tipo de mensaje");
    ?>
</body>
</html>