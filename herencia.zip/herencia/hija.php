<?php
require_once('padre.php');//necesario porque heredas de Padre
class Hija extends Padre{

public function saludarHija(){
    echo("<p>hola, desde la clase hija</p>");
}

//sobrecarga, overload
public function saludarHija(string $saludo){
    echo("<p>hola, desde la clase hija ".$saludo."</p>");
}

//sobreescritura : override el método de la padre
public function saludarPadre(){
    echo("<p>hola, desde la clase padre, pero soy la hija</p>");
}

}//cierra clase