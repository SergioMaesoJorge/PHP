<?php

class Cliente{

//propiedad - atributos - campos
public string $nombre;
private string $ciudad;//modificador de visilidad, acceso
public float $presupuesto;

//constructor //insert
public function __construct(string $nombre,string $ciudad,float $presupuesto ){

    $this->nombre=$nombre;
    $this->ciudad=$ciudad;
    $this->presupuesto=$presupuesto;

}//cierra constructor
//getters - setters
//funcionalidad encapsulamiento
//update
public function setCiudad(string $ciudad){
    $this->ciudad=$ciudad;
}

//resto de métodos
public function fichaCliente(){
    echo("<p>Datos del cliente</p>");
    echo("<p>Nombre: ".$this->nombre."</p>");
    echo("<p>Ciudad: ".$this->ciudad."</p>");
    echo("<p>Presupuesto: ".$this->presupuesto."</p>");
}//cierra fichaCliente
}//cierra class