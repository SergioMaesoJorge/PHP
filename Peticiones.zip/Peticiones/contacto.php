<?php
$correo=$_POST["Correo"];
$telefono = $_POST["Telefono"];
$terminos = $_POST["Terminos"];
if ($terminos)
    echo("Se ha registrado el correo");
else 
    echo ("No se ha registrado el correo");