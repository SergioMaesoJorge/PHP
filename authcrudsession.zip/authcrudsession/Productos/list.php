<?php
require_once('../config/db.php');

$consulta="select * from productos";
$resultado = $conn->query($consulta);
while ($producto = $resultado->fetch()){ //O bien ($resultado->fetch(PDO::FETCH_BOTH)
    echo $producto['id']." ".$producto[1]." ".$producto['unidades']."<br>";
}