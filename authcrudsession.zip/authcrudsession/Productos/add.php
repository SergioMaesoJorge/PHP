<?php
session_start();
if(isset($_SESSION['token'])){
    if($_SESSION['token']==session_id()){
        require_once('../config/db.php');
        $insertar= "INSERT INTO `productos` (`id`, `nombre`, `unidades`, `precio`, `fecha_caducidad`) VALUES (NULL, 'sombrero', '14', '9.95', '2023-02-01');";
        $registros = $conn->exec($insertar);
        if ($registros){
            echo "Se han activado $registros registros.";
        }
        else{
            echo("no hay login");
        }
    }
}
else{
    echo("no hay sesión");
}
