<?php
require_once('../config/db.php');
$login_user="admin@admin.com";
$login_pasword="123";
$consulta="select * from usuarios";
$resultado = $conn->query($consulta);
while ($usuario = $resultado->fetch()){ //O bien ($resultado->fetch(PDO::FETCH_BOTH)
    if($usuario['email']==$login_user and $usuario['password']==$login_pasword){
        echo "Login correcto";
        session_start();
        $_SESSION['token']=session_id();
    }
    else{
        echo "Login incorrecto";
    }
}
?>
<br>
<a href="index.html">Volver al menú</a>