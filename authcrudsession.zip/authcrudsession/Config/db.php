<?php 
$conn = new PDO('mysql:host=localhost;dbname=tienda', 'root', '');
var_dump($conn);