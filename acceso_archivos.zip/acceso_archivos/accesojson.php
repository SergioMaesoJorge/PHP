<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Gestionar JSON</h2>
    <a href="https://code.tutsplus.com/es/tutorials/how-to-parse-json-in-php--cms-36994">enlace de referencia</a>"
<?php
$archivo_json = file_get_contents('archivos/products.json');
//$decoded_json = json_decode($archivo_json, false);
//$productos=$decoded_json->products;

$decoded_json = json_decode($archivo_json, true);//lee como matriz
$productos=$decoded_json['products'];

foreach($productos as $producto) {
    echo "<p>".$producto['title']."</p>";
}

?>
</body>
</html>