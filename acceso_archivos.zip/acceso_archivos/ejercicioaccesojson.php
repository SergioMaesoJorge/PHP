<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Consumir JSON</h2>
    <p>Busca un archivo json y descárgalo</p>
    <p>Muestra en la web el contenido del archivo</p>
    <a href="https://jsonplaceholder.typicode.com/photos">Datos json</a>
    <p>Muestra el título, el enlace y la foto</p>

    <?php
    $archivo_json = file_get_contents('archivos/photos.json');
    $decoded_json = json_decode($archivo_json, true);//lee como matriz
    //$productos=$decoded_json['products'];
    
    foreach($decoded_json as $photo) {
        echo "<h3>".$photo['title']."</h3>";
        echo "<p><a href='".$photo['url']."'>Ver foto</a></p>";
        echo "<img src='".$photo['thumbnailUrl']."'>";
        echo "<hr>";
    }

    ?>
</body>
</html>
