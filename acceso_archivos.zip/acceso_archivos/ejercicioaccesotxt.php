<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Consultar y enviar sugerencias</h2>
    <p>Diseñar un formulario que permita escribir un comentario</p>
    <p>Al pulsar el botón enviar, se guarda el comentario en un archivo de texto</p>
    <p>Automáticamente, se muestra el contenido del archivo de comentarios</p>
    <p>Añadir en cada nuevo comentario, la fecha y la hora</p>

    <form action="" method="post">
<p>Introduce tu comentario <input type="text" name="comentario"></p>
<input type="submit" value="enviar">
    </form>

<?php
//escribir en un archivo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comentario=$_POST["comentario"];
    $fecha=date("d-m-Y h:i:s");
    $archivo=fopen("archivos/comentarios.txt","a");//si el archivo no existe, lo crea
    $comentario_guardado="fecha de comentario ".$fecha.":".$comentario."\r\n";
        fwrite($archivo,$comentario_guardado);
        fclose($archivo);
}
?>
<hr>
<h3>Comentarios añadidos</h3>
<?php
$archivo_leer=fopen("archivos/comentarios.txt","r");
$contenido="";
//$lectura=fgets($archivo_leer); //sólo lees una línea
while($lectura=fgets($archivo_leer)){
    $contenido.="<p>".$lectura."<p>";
}
fclose($archivo_leer);
echo($contenido);
?>
</body>
</html>