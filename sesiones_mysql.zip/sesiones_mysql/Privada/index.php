<?php
session_start();
if (isset($_SESSION['token'])){
    echo "b";
}
else{
    header('location:../auth/login.php');
}