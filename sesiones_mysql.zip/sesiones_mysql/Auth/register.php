<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2><marquee>Alta de nuevo usuario</marquee></h2>
    <form action="" method="post">
        <p><marquee>Correo: <input type="email" name="correo"></marquee></p>
        <p><marquee>Contraseña: <input type="password" name="password"></marquee></p>
        <p><marquee>Repetir contraseña: <input type="password" name="password2"></marquee></p>
        <p><marquee><input type="checkbox" name="cb">Acepto la política de privacidad</marquee></p>
        <p><marquee><input type="submit" value="Registro" name="dato"></marquee></p>
    </form>
    <?php
    if(isset($_POST['dato'])){
        $correo=$_POST['correo'];
        $password=$_POST['password'];
        $password2=$_POST['password2'];
        if($password==$password2){
        $conn=new PDO("mysql:host=localhost;port=3306;dbname=test","root","");
        $consulta="INSERT INTO usuarios (id, correo, password, fecha)  
       VALUES (NULL,'".$correo."', '".$password."', NOW());";
        $conn->query($consulta);
        header('location:login.php');
        echo("<p>Usuario registrado</p>");
        }
    else{
        echo("<p>Contraseña incorrecta</p>");
    }
    }
    ?>
</body>
</html>