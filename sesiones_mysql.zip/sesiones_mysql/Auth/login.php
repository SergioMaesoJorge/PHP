<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
        <p>Correo: <input type="email" name="correo"></p>
        <p>Contraseña: <input type="password" name="password"></p>
        <p><input type="submit" value="Login" name="dato"></p>
    </form>
    <?php
    if(isset($_POST['dato'])){
        $correo=$_POST['correo'];
        $password=$_POST['password'];
        $conn=new PDO("mysql:host=localhost;port=3306;dbname=test","root","");
        $consulta="SELECT correo,password FROM usuarios;";
        $conn->query($consulta);
        //header('location:login.php');
        //echo("<p>Usuario registrado</p>");
        }
    ?>
</body>
</html>