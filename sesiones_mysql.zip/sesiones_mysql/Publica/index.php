<?php
echo "a";
echo("<a href='verproductos.php'>Consultar productos</a>");