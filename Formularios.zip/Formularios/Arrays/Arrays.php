<?php
$ciudades=["Madrid",15,TRUE,14.58,"Sevilla",'Juan'];
echo ($ciudades);
print($ciudades);
print_r($ciudades);
var_dump($ciudades);
echo ("<hr>");
foreach ($ciudades as $ciudad)
    echo ("<p>".$ciudad."</p>");
echo ("<hr>");
$ciudades[10] = "Cosa";
var_dump($ciudades);
echo ("<hr>");
unset($ciudades[3]);
var_dump($ciudades);
?>