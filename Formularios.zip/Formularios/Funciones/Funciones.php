<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: gray">
<?php
function saludar($nombre){
    //echo ("<p>Hola qué tal</p>");
    return "Hola, qué tal, ".$nombre;
};
//saludar();
echo (saludar("Juan"));
echo ("<hr>");

function viajar($destino="Roma"){
    return "Nos vamos de viaje a ".$destino;
};
echo(viajar());
echo ("<hr>");
echo(viajar("Lisboa"));
echo ("<hr>");
function calcular(){
    return 2 + 2;
}
$c = "calcular";
echo ($c());
echo ("<hr>");
$salida = function () {
    $mensaje = "En un lugar de la Mancha";
    var_dump($mensaje);
};
$salida();

?>
</body>
</html>
