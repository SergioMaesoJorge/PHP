<?php
$temp = [
    "lunes" => 25.75,
    "martes" => 16.65,
    "miércoles" => 89.69,
    "jueves" => -59.71,
    "viernes" => 8.88,
    "sábado" => 44.44,
    "Domingo" => 14.85
];
$media = 0;
foreach ($temp as $t) {
    echo ("<p>" . $t . "</p>");
    $media = $media + $t;
};
$dias = count($temp);
$media= $media / $dias;
echo(round($media,2));

echo("<hr>");
$unidades = 150;
$precio = 9.95;
echo(round($unidades * $precio,2));
echo("<hr>");

$clientes = [
    "Antonio" => 25795.64,
    "Marcos" => 6478.58,
    "Juan" => 1419.14
];
foreach ($clientes as $nombre => $factura) {
    if ($factura > 1000)
        $iva = 1.05;
    else
        $iva = 1.21;
    echo ("<p>El cliente " . $nombre . " ha tenido una venta por valor de " . $factura . " y después del iva la factura es " .round(($factura * $iva),2) . "</p>");

};
echo("<hr>");
//crea un formulario en html con los campos para introducir
//tu correo, tu contraseña y la ciudad a elegir de una lista de 4
//al enviar datos
//si la contraseña es 123
//te muestra la ciudad elegida y el mensaje que está disponible
//si no es la ocntraseña 123 te dice que la ciudad no está disponible
echo ("<h2>Se han recibido los datos</h2>");
echo("<hr>");
$correo = $_POST["Correo"];
$psw = $_POST["Contraseña"];
$ciudad = $_POST["Ciudad"];
if ($psw == "123")
    echo ("<p>La ciudad " . $ciudad . " está disponible</p>");
else
    echo ("<p>La ciudad no está disponible</p>");

