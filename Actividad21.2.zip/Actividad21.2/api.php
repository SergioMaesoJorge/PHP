<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
</head>
<body style="background-color:beige">
<?php
$archivo=json_decode(file_get_contents('https://api.nasa.gov/planetary/apod?api_key=f7Xu9c1hF6PG2G3m4AtPkWQKhmrqtLUjVCwjR3HM'),true);

echo("<p>".$archivo['copyright']."</p>");
echo("<p>".$archivo['date']."</p>");
echo("<p>".$archivo['explanation']."</p>");
echo("<img style='width=50%' src='".$archivo['hdurl']."'>");
echo("<p>".$archivo['title']."</p>");
echo("<img src='".$archivo['url']."'>");
?>
<script type="text/javascript" src="js/materialize.min.js"></script>
</body>
</html>