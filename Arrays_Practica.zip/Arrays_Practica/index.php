<?php
$numerica = ["Juan","Pepe","Carlos"];
$asociativa = [
    "Antonio"=> 25,
    "Manuel" => 32,
    "Paco" => 82
];
$dimensional =[ [
    "Nombre" => "Persona",
    "Apellidos" => "Amigable",
    "Número favorito" => 36
],

[
    "Nombre" => "Rodolfo",
    "Apellidos" => "Fernández",
    "Número favorito" => 42
],

[
    "Nombre" => "John",
    "Apellidos" => "Sánchez",
    "Número favorito" => 72
]

];

array_push($numerica, "Javier");
array_push($asociativa, ["Extra1" => 67]);
array_push($dimensional, ["Nombre" => "Extra2","Apellidos"=>"El Extra","Número favorito" =>71 ]);

$arrays = [$numerica,$asociativa,$dimensional];
for ($i=0;$i<3;$i++){
    print_r (array_values($arrays[$i]));
};

echo ("<p></p>");
array_pop($numerica);
array_pop($asociativa);
array_pop($dimensional);

$arrays = [$numerica,$asociativa,$dimensional];
for ($i=0;$i<3;$i++){
    print_r (array_values($arrays[$i]));
};