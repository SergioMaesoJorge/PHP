<?php
echo ("<h2>Nuevo usuario</h2>");
$connPDO=new PDO("pgsql:host=localhost;dbname=test","postgres","curso");

$consulta = "INSERT INTO mascotas (nombre, edad) VALUES ('".$_POST['nombre']."', ".$_POST['edad'].")";

$preparar = $connPDO->prepare($consulta);
$resultado = $preparar->execute();

$resultado = $connPDO->query("SELECT * from  mascotas");
while ($row = $resultado->fetch_assoc()) {
    echo ("<table>");
    echo ("<tr>");
    echo ("<td>" . $row["id"] . "</td>");
    echo "<td>" . $row["nombre"] . "</td>";
    echo "<td>" . $row["edad"] . "</td>";
    echo "</tr>";

    echo ("</table>");
}
header("location: index.php");