<?php
interface Requisitos{
    public function combatir();
    public function resultado(bool $resultado);
    public function pasarNivel(int $nivel);
}