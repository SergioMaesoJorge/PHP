<?php
require_once("requisitos.php");
class Juego implements Requisitos{
    public function __construct($jugador1,$jugador2,$version){
        $this->jugador1 = $jugador1;
        $this->jugador2 = $jugador2;
        $this->version = $version;
    }
    public function combatir(){
        if($this->version == "Educativa"){
            echo ("<p>Esta es la versión educativa, procederemos a hacer 10 preguntas sobre física y química</p>");
        }
        if ($this->version == "Lúdica") {
            echo ("<p>Los dos jugadores van a combatir</p>");
        }

    }
    public function resultado(bool $resultado =0){
        if($this->version == "Educativa"){

        }
        if($this->version == "Lúdica"){
            $resultado=rand(1, 2);
            if ($resultado = 1)
                echo ("<p>Victoria aplastante del jugador 1</p>");
            if ($resultado = 2)
                echo ("<p>El jugador 2 le ha dado una paliza al jugador 1</p>");
        }
    }
    public function pasarNivel(int $nivel){

    }
}