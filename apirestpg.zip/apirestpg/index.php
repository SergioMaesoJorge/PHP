<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>APIs en Postgres</h2>
    <form method="get" action="post.php">
        <input type="submit" value="Petición get">
    </form>
    <form method="get" action="post.php">
        <input type="text" name="status">
        <input type="submit" value="Enviar estatus">
    </form>
    <form method="post" action="post.php">
        <input type="text" name="title">
        <input type="text" name="status">
        <input type="text" name="content">
        <input type="number" name="user_id">
        <input type="submit" value="Post">
    </form>
</body>
</html>