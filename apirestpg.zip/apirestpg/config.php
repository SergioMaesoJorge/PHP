<?php
$db = [
    'host' => 'localhost',
    'username' => 'postgres',
    'password' => 'curso',
    'db' => 'postgres' //Cambiar al nombre de tu base de datos
];
?>