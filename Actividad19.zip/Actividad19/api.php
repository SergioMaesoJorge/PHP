<?php
echo(file_get_contents('https://api.nasa.gov/planetary/apod?api_key=f7Xu9c1hF6PG2G3m4AtPkWQKhmrqtLUjVCwjR3HM'));