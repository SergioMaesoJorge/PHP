<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Arrays en PHP</h2>
    <a href="https://www.php.net/manual/en/language.types.array.php">Enlace de referencia</a>
    <?php
    $paises=[
        "Italia" => "Roma",
        "Francia" => "París",
        "Alemania" => "Berlín",
        25 => "Estocolmo",
        "Noruega" => TRUE
    ];
    echo("<p>".$paises["Francia"]."</p>");
    echo("<p>".$paises[25]."</p>");
    $clientes=array(
        "Indra" => 1500,
        "Telefónica" => 1965.95,
        "Repsol" => "Castellana"
    );
    echo("<p>".$clientes["Telefónica"]."</p>");
    $colores=["red","green","blue"];
    echo("<p style='color:green'>Esto es un texto de prueba</p>");
    echo("<p style='color:".$colores[0]."'>Esto es un texto de prueba</p>");
    for($i=0;$i<3;$i++)
    {
        echo($colores[$i]);
    }
    ?>
</body>
</html>