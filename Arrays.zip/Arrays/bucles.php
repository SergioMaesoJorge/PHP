<?php
for($i=0;$i<=10;$i++){
    echo("<p>".$i."</p>");
}


$ciudades=["Valencia","Sevilla","Jaén","Segovia"];

foreach($ciudades as $ciudad)
    echo ("<p>".$ciudad."</p>");