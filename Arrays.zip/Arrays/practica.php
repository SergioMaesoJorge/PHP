<?php

$facturas=[1200.95,52.25,3090.95,899.55];
foreach($facturas as $factura)
    if($factura > 1000)
        echo("<p>La factura es de ".$factura."€"."</p>");

$numeros=[3,5,7,9,11,13];
foreach($numeros as $numero)
    echo("<p>El cubo del número: ".$numero." es ".pow($numero,3) ."</p>");

$temperaturas=[
    "lunes" => 24,
    "Martes" => 35,
    "Miércoles" => 53,
    "Jueves" => -5,
    "Viernes" => 19,
    "Sábado" => 3,
    "Domingo" => 37
];

echo("<p style='color:violet'>La temperatura que hubo el miércoles fue de ".$temperaturas["Miércoles"]." grados");

