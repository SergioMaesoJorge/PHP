<?php
$nombre=$_POST["nombre"];
$comentario=$_POST["comentario"];
$nombre_comentario= "Nombre: ".$nombre." Comentario: ".$comentario;
$archivo=fopen("archivo.txt","a");
fwrite($archivo,$nombre_comentario);
$lectura=fopen("archivo.txt","r");
$leer=fgets($lectura);
echo($leer);
