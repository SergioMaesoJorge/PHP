<?php
function grupo(){
    $correo = $_POST["correo"];
    $grupo = rand(1, 3);
    if ($grupo == 1){
        echo ("<p>El usuario con correo " . $correo . " pertenece al grupo 1</p>");
    }
    if ($grupo == 2){
        echo ("<p>El usuario con correo " . $correo . " pertenece al grupo 1</p>");
    }
    if ($grupo == 3){
        echo ("<p>El usuario con correo " . $correo . " puede elegir si quiere ir al grupo 1 o al 2</p>");
    }
}
grupo();