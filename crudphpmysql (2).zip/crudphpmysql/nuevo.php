<?php
$conn=mysqli_connect("localhost:3306","root","","test");
$nombre = $_POST["nombre"];
$numero = $_POST["numero"];
$aficiones = $_POST["aficiones"];

$sql = "INSERT INTO test.persona VALUES ('aa',5,'ad')";

echo ("<p>Se han añadido correctamente: " . $nombre . $numero . $aficiones . "</p>");
