<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hito Individual</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <ul>
  <li><a href="formulario.php">Formulario</a></li>
  <li><a href="formularioEnviado.php">Publicaciones</a></li>
</ul>
    <h2 id="introduccion">Introducción: </h2>
    <p id="introduccion2">Antes de tratar las diferencias entre los lenguajes de programación orientada a objetos, de programación dirigida por eventos (también referida como programación orientada a eventos o programación basada en eventos) y los lenguajes procedimentales es importante saber qué son y qué lenguajes dan soporte a estos paradigmas. </p>
    <img id="portada" src="https://www.qualitydevs.com/wp-content/uploads/2021/05/PHP-Quality-Devs-1-1288x724.jpg">
    <div class="table-responsive">
        <table class="table">
            <tr class="filaTabla">
                <th class="columnaTabla">Programación orientada a objetos</th>
                <th class="columnaTabla">Programación basada en eventos</th>
                <th class="columnaTabla">Programación procedimental</th>
            </tr>
            <tr class="filaTabla2">
                <td class="columnaTabla2">
                    La programación orientada a objetos es un modelo de programación que organiza el diseño del software alrededor de datos u objetos, en vez de funciones y lógica. Un objeto puede ser definido como un campo de datos que tiene un único comportamiento y atributos. 
                    Esta se centra en los objetos que los desarrolladores quieren manipular, en vez de la lógica requerida para manipularlos.
                    También es importante conocer cuáles son los principales lenguajes que utilizan la POO (programación orientada a objetos). Estos son: Java, C#, Python, Ruby, PHP y TypeScript.
                </td>
                <td class="columnaTabla2">La programación basada en eventos es excelente para trabajar en sistemas complejos. Este es un paradigma de programación donde las entidades (objetos, servicios, etc.) se comunican entre ellos mandándose mensajes mediante un intermediario. Estos mensajes se almacenan en una cola antes de que los reciban los usuarios. 
                    La POE separa al receptor y a la fuente de los eventos, lo que otorga algunos beneficios interesantes. Por ejemplo, varios receptores y varias fuentes de eventos pueden colaborar para procesar peticiones. 
                    Hay varios componentes de este paradigma. Estos son los eventos (piezas de datos que los envían los productores o fuentes de datos), los productores (entidades que generan eventos y los envían a una cola de mensajes), la cola de mensajes (repositorios de mensajes o eventos que se pueden almacenar en la memoria), y los consumidores (los receptores de los eventos que generan los productores y que se almacenan en la cola de mensajes). 
                    Cualquier lenguaje que utilice la programación orientada a objetos tiene soporte para la programación basada en eventos. Ejemplos notables son Visual Basic, Visual C++ y Java.
                </td>
                <td class="columnaTabla2">Un lenguaje de programación procedimental (procedural programming language en inglés) sigue, en orden, un conjunto de comandos. Este paradigma de programación hace uso de funciones, condicionales y variables para crear programas que permiten al ordenador calcular y mostrar el resultado deseado. 
                    Algunos lenguajes procedimentales son BASIC, C, FORTRAN, Java y Pascal. 
                </td>
            </tr>
        </table>
    </div>
    <?php
    $ip=$_SERVER['REMOTE_ADDR'];
    $fecha=date('d-m-y');
    setcookie($ip,$fecha);
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>