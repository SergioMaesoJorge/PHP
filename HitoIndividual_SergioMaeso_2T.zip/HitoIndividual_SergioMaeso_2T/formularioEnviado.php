<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario aceptado</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body class="formularioEnviado">
    <h1 id="portada3">El formulario se ha enviado con éxito</h1>
    <p id="parrafoFormularioEnviado">A continuación se muestran las publicaciones de otros usuarios</p>
    <p><a class="enlaces" href="editar.php">Eliminar/Actualizar publicaciones</a></p>
    <?php
    $conn = new PDO('mysql:host=localhost;dbname=hito_individual_sm', 'root', '');
    $consulta="select * from publicaciones";
    $resultado = $conn->query($consulta);
    while ($publicacion = $resultado->fetch()){
        echo "<b>**Publicación numero: ".$publicacion['id']."**</b> <p>Título: ".$publicacion['titulo']." <br>Contenido: ".$publicacion['contenido'].
        " <br>Fecha de publicación: ".$publicacion['fecha']." <br>Imagen: ".$publicacion['imagen']." <br>Publicado por:".$publicacion['correo']."</p><br>";
    }
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>