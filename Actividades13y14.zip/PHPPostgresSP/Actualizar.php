<?php
$dsn = "pgsql:host=localhost;dbname=postgres";
$conn = new PDO($dsn,"postgres","curso");
//var_dump($conn);
$sql = 'CALL public.sp_update_productos(?, ?)';
$stmt = $conn->prepare($sql);

$nombre = $_POST["nombre"];
$unidades = $_POST["unidades"];

$stmt->bindParam(1, $nombre);
$stmt->bindParam(2, $unidades);

$stmt->execute();
echo ("<p>Registro insertado</p>");