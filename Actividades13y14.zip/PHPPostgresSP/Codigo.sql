CREATE TABLE IF NOT EXISTS public.productos
(
    id serial, 
    nombre character varying(50)  NOT NULL,
    unidades smallint NOT NULL,
    CONSTRAINT productos_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.productos
    OWNER to postgres;
	
insert into public.productos (nombre,unidades) values ('Pantalón',25);
select * from productos;
create or replace procedure
public.sp_add_productos (IN nombre text, in unidades numeric)
begin atomic insert into public.productos (nombre,unidades) values(nombre,unidades);
end;

create or replace procedure
public.sp_update_productos (IN n text, in ud numeric)
begin atomic update public.productos set unidades=ud where nombre = n;
end;

call public.sp_update_productos('abrigo',333);

create or replace procedure
public.sp_delete_productos (IN n text)
begin atomic delete from public.productos where nombre = n;
end;

call public.sp_delete_productos('abrigo');