<?php
echo ("<h2>Nuevo usuario</h2>");
$connPDO=new PDO("pgsql:host=localhost;dbname=test","postgres","curso");
var_dump($connPDO);

$consulta = "INSERT INTO mascotas (nombre, edad) VALUES ('".$_POST['nombre']."', ".$_POST['edad'].")";

$preparar = $connPDO->prepare($consulta);
$insertar = $preparar->execute();
var_dump($insertar);