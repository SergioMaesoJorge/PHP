<?php
require_once("practica.php");
$ciudad = new Ciudad("Madrid", 2854242, 5.85, TRUE);
$ciudad->fichaCiudad();
$ciudad->trafico();