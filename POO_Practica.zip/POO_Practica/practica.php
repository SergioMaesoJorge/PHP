<?php
class Ciudad{
    private $nombre;
    private $poblacion;
    private $temperatura;
    private $es_capital;
    public function __construct ($nombre,$poblacion,$temperatura,$es_capital){
        $this->nombre = $nombre;
        $this->poblacion=$poblacion;
        $this->temperatura = $temperatura;
        $this->es_capital = $es_capital;
    }
    public function fichaCiudad(){
        echo ("<p>Los datos de la ciudad son: ".$this->nombre." ".$this->poblacion." ".$this->temperatura." ".$this->es_capital."</p>");
    }
    public function trafico(){
        if($this->es_capital) {
            if ($this->poblacion >= 50000) {
                echo ("<p>Acceso al tráfico restringido</p>");
            }
        }
    }
}